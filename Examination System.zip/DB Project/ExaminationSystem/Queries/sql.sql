  use ExaminationSystem
 --InsertQuestion
 go
 create or alter proc InsertQuestion @ques_id int, @Exam_id int, @ques varchar(max),
@answer varchar(50),@type varchar(50),@degree int
as
if exists(select Exam_id from Exam where Exam_id=@Exam_id)
begin
 insert into Questions(Ques_id,Exam_id,Question,Type,Ques_Answer,Degree) 
 values(@ques_id,@Exam_id,@ques,@type,@answer,@degree)
end
else
begin
select 'Question not exist'
end
--ExamProcedure
go
create or alter proc ExamCreation @id int,@data varchar(max), @duration time,@course varchar(50)
as
  declare @c_id int;
  select @c_id=crs_id from Courses where crs_Name=@course
 insert into Exam values(@id,@data,@duration,@c_id);

 go
 --SelectExam
create or alter proc SelectExam @id int,@courseName varchar(50), @numOfQuesTrue int, @numOfchoice int
as
declare @examid int;
 
 select @examid=e.Exam_id from Exam e inner join Courses c on e.Course_id=c.crs_id where c.crs_Name=@courseName
 select * from(
 SELECT TOP (@numOfchoice) Question FROM Questions where Type='choice' and Exam_id=@examid
ORDER BY NEWID() )as newtabel
union
 select * from(
 SELECT TOP (@numOfchoice) Question FROM Questions where Type='trueorfalse' and Exam_id=@examid
ORDER BY NEWID() )as newtabel2

exec SelectExam 1,'Programming',1,1

----------------------------------------------------------
 go
 create or alter proc ExamCorrection @std_username int,@Answer varchar(50),@Exam_id int,@ques_id int
as
 declare @usr_id int;
 declare @degree int;
 declare @correctAnswer varchar(50);
  select @usr_id=[Std-id] from Student where Username=@std_username
  
  select @correctAnswer=Ques_Answer from Questions where Ques_id=@ques_id
  if(@correctAnswer!=@Answer)
  begin
   set @degree=0;
  end
  else
  begin
   select @degree=Degree from Questions where Ques_id=@ques_id
  end

  insert into Ques_Answer values(@Exam_id,@ques_id,@usr_id,@Answer,@degree)

------------------------------------------------------------------------
 go
 create or alter proc getFinalResult @Exam_id int,@std_id int
 as
 select FinalDegree from FinalDegree where std_id=@std_id and Exam_id=@Exam_id

 go

 --------------------------------------------------
  create or alter proc insertStudentFinalDegree @std_id int,@Exam_id int
 as
 declare @res int; 
 select @res=sum(ResultDegree) from Ques_Answer where Std_id=@std_id and Exam_id=@Exam_id
insert into FinalDegree values(@std_id,@Exam_id,@res)
 go


