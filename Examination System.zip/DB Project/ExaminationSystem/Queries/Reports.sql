--1)Report that returns the students information according to Department No parameter.
go
create or alter proc getStudent @id int
as
begin
select * from Student where Dept_id = @id
end

exec getStudent 1
----------------------------------------
--2)Report that takes the student ID and returns the grades of the student in all courses.
go
create or alter proc getGrade @id int
as
begin
select grade, Total_Deg from Std_Crs
where std_id = @id
end

exec getGrade 1

-------------------------------------------------------
--3)Report that takes the instructor ID 
--returns the name of the courses that he teaches and the number of student per course.
go
create or alter proc getInfo @id int
as
begin
select COUNT(s.[Std-id]) as [Number of Students],c.crs_Name from Student s inner join Std_Crs sc
on s.[Std-id]= sc.std_id
inner join Courses c on c.crs_id = sc.crs_id
inner join Course_ins crs on crs.Course_id = c.crs_id
inner join Instructor ins on ins.Ins_id=crs.ins_id
where ins.Ins_id = @id
group by c.crs_Name
end

exec getInfo 1


------------------------------------------------------
--4)Report that takes course ID and returns its topics 
go
create or alter proc getTopic @id int
as
begin
select Topic_Name from Topic where Crs_id = @id
end

exec getTopic 3

------------------------------------------
--5)Report that takes exam number and returns Questions in it
go
create or alter proc GetQuestion @id int
as
begin
select Q.Question from Questions Q inner join Ques_Answer QA
on Q.Ques_id = QA.Ques_id inner join Exam E
on E.Exam_id = QA.Exam_id
where E.Exam_id = @id
end


exec GetQuestion 46



--6)Report that takes exam number and the student ID 
--then returns the Questions in this exam with the student answers.
go
create or alter proc getAnswer @exam_id int, @std_id int
as
begin
select Q.Question, QA.Answer from Questions Q, Ques_Answer QA where QA.Exam_id = @exam_id and QA.Std_id = @std_id 
end

exec getAnswer 46,1
