select * from Instructor
go
create or alter proc InsertNewInst @Ins_id int, @Fname varchar(10), @Lname varchar(10), 
@Salary int,@Dept_id int, @Manager int, @Username int
as

if exists (select Dept_id from Department where Dept_id = @Dept_id)
begin

insert into dbo.Instructor(Ins_id ,Fname,Lname,Salary,Dept_id,Manger,Username)
values(@Ins_id,@Fname, @Lname, @Salary, @Dept_id, @Manager, @Username)

end
else
begin
select 'Department not Found'
end

exec InsertNewInst 6,'Hanya','Hesham',5000,2,1,123

insert into dbo.Instructor(Ins_id ,Fname,Lname,Salary,Dept_id,Manger,Username)
values(5,'Hanya','Hesham',5000,3,1,123)

/*******************************************/
select * from Student
go
create or alter proc InsertNewStudent @Fname varchar(10), @Lname varchar(10), @Address varchar(20), @Dob date, @Dept_id int, @Username int
as
if exists (select Dept_id from Department where Dept_id = @Dept_id)
begin
insert into dbo.Student(Fname, Lname, Address, Dob, Dept_id, Username)
values(@Fname, @Lname, @Address, @Dob, @Dept_id, @Username)
end
else
begin
select 'Department not Found'
end


/*******************************************/
select * from Courses
select * from Topic
go
create or alter proc InsertTopic @Crs_id int, @Top_Name varchar(50)
as
if exists (select crs_id from Courses where crs_id = @Crs_id)
begin
insert into dbo.Topic(Crs_id, Topic_Name)
values(@Crs_id, @Top_Name)
end
else
begin
select 'Course not Found'
end

/************************************************/
select * from Choices
select * from Questions
go
create or alter proc InsertChoice @Ques_id int, @choice varchar(50)
as
if exists (select Ques_id from Questions where Ques_id = @Ques_id)
begin
insert into dbo.Choices(Ques_id,Choice)
values(@Ques_id, @choice)
end
else
begin
select 'Question not Found'
end

/*******************************************************/
select * from Std_Crs

go
create or alter proc InsertStdCourse @crs_id int, @std_id int, @grade int
as
if exists(select st.[Std-id], crs.crs_id from Student as st, Courses as crs where st.[Std-id] = @std_id and crs.crs_id = @crs_id)
begin
insert into dbo.Std_Crs(crs_id, std_id, grade)
values(@crs_id, @std_id, @grade)
end
else
begin
select 'Student not exist'
end

/*******************************************************/
go
 create or alter Proc InsertCourses
       @crs_name nchar(50) 
      as
	    begin

		      Insert into Courses
			      (
				    Crs_name
				  )
			  Values
			     ( 
			       @crs_name
			     )
		end

		----------------------------------------------------------------------------

go		 
create or alter Proc InsertDepartment
       @dept_id int, @dept_name nchar(30) 
      as
	    begin

		      Insert into Department
			      (
					Dept_id,
				    Dept_name
				  )
			  Values
			     ( 
					@dept_id,
			       @dept_name
			     )
		end
		exec InsertDepartment 4,'SD'

		-------------------------------------------------------------------------

go		
create or alter Proc InsertExam
          @data nchar(20) ,@duration time
      as
	    begin
		 
		      Insert into Exam
			      (
				    Exam_data,
					Duration
				  )
			  Values
			     ( 
			       @data,
				   @duration
			     )
		end


		-------------------------------------------------------------------------------

go		
create or alter Proc InsertIns_Course
       @crs_ID int ,@ins_ID int 
      as
	    begin


		   if exists(select c.*,i.* from Courses c , Instructor i where c.crs_id=@crs_ID and i.Ins_id=@ins_ID)
		     begin
		      Insert into Course_ins
			      (
				    Course_id,
					ins_id
				  )
			  Values
			     ( 
			       @crs_ID,
				   @ins_ID
			     )
			 end
		   else
		       select 'there is an ID doesnt exist in parent table'
		end

		------------------------------------------------------------------------------



go		
create or alter Proc QuestionAnswer
       @e_id int ,@q_id int,@s_id int,@as varchar(50), @ResDegree int 
      as
	    begin


		   if exists(select ST.*,QT.*,ET.* from Student ST ,Questions QT, Exam ET where ST.[Std-id]=@s_id and QT.Ques_id=@q_id and ET.Exam_id=@e_id)
		     begin
		      Insert into Ques_Answer
			      (
				    Exam_id,
					Ques_id,
					Std_id,
					Answer,
					ResultDegree
				  )
			  Values
			     ( 
			       @e_id,
				   @q_id,
				   @s_id,
				   @as,
				   @ResDegree
			     )
			 end
		   else
		       select 'there is an ID doesnt exist in parent table'
		end

		exec QuestionAnswer 5,4,4,'true',90

		-------------------------------------------------------------------------------
 go
 create or alter proc insertStudentFinalDegree @std_id int,@Exam_id int
 as
 declare @res int; 
 select @res=sum(ResultDegree) from Ques_Answer where Std_id=@std_id and Exam_id=@Exam_id
 insert into FinalDegree values(@std_id,@Exam_id,@res)

 ----------------------------------------------------
 
 
 select * from Questions
 go
 create or alter proc InsertQuestion @ques_id int, @Exam_id int, @ques varchar(max),
@answer varchar(50),@type varchar(50),@degree int
as
if exists(select Exam_id from Exam where Exam_id=@Exam_id)
begin
 insert into Questions(Ques_id,Exam_id,Question,Type,Ques_Answer,Degree) 
 values(@ques_id,@Exam_id,@ques,@type,@answer,@degree)
end
else
begin
select 'Question not exist'
end

exec InsertQuestion 4,2, 'is priamry key accept null', 'boolean', 'true or false', 90

















