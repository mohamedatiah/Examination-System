	GO
create or alter Proc delete_Department
	@id int
	as 
		begin

		if exists(select Dept_id from Department where Dept_id=@id )
		begin
		  UPDATE Instructor SET Dept_id = NULL WHERE Dept_id=@id 
		  UPDATE Student SET Dept_id = NULL WHERE Dept_id=@id
		  delete from Department 
		  where dept_id=@id
		  end
		  else
		  begin
		  select 'invalid ID'
		  end		
   end

   --------------------------------------------------------------------------------------


   		GO
create or alter Proc delete_Courses
	@id int
	as 
		begin
			if exists(select * from   Courses where crs_id =@id)
		    begin

		  delete from Topic   WHERE Crs_id=@id 
		  delete from Std_Crs where crs_id=@id
		  delete from Course_ins where Course_id=@id
		  delete from Courses where crs_id=@id
			end
			else
	      select 'there is no ID in Courses table ='+CONVERT(varchar(10),@id)
   end

   --------------------------------------------------------------------------------------------

    GO
create or alter Proc delete_Exam
	@id int
	as 
		begin
			if exists(select * from   Exam where Exam_id = @id)
		    begin

		  delete from Ques_Answer where Exam_id=@id
		  delete from Exam where Exam_id=@id
			end
			else
	      select 'there is no ID in Exam table ='+CONVERT(varchar(10),@id)
   end

   ---------------------------------------------------------------------------------------

       GO
create or alter Proc delete_courseIns @in_id int ,@crs_id int
	as 
		begin
			if exists(select * from   Course_ins where ins_id =@in_id and Course_id=@crs_id)
		    begin

			 delete from Course_ins where ins_id=@in_id and Course_id=@crs_id;
			end
			else
	      select 'there is no ID '
			
   end
  

   ------------------------------------------------------------------------------------------
   GO
   create or alter proc  delete_Question
	@id int
	as 
		begin
			if exists(select * from   Questions where Ques_id = @id)
		    begin

		  delete from Choices where Ques_id=@id
		  delete from Ques_Answer where Ques_id=@id
		  delete from Questions where Ques_id=@id
			end
			else
	      select 'there is no ID in Question table ='+CONVERT(varchar(10),@id)
   end

   ------------------------------------------------------------------------------

          GO
create or alter Proc delete_QuestionAnswer @e_id int ,@q_id int ,@S_id int
	as 
		begin
			if exists(select * from   Ques_Answer where Exam_id = @e_id and Ques_id=@q_id and Std_id=@S_id)
		    begin

			 delete from Ques_Answer where Exam_id=@e_id  and Ques_id=@q_id and Std_id=@S_id;
			end
			else
	      select 'there is no ID '
			
   end

  ------------------------------------------------------------------------------------

go
create or alter proc DeleteStudent @id int
as
if exists(select * from Student where [Std-id]=@id)
begin
delete Ques_Answer where Std_id = @id
delete Std_Crs where std_id = @id
delete from Student
where [Std-id] = @id
end
else
begin
select 'There is no Student with that ID'
end
--------------------------------------------
go
create or alter proc DeleteInstructor @id int
as
if exists (select * from Instructor where Ins_id = @id)
begin
delete Course_ins where ins_id = @id
update Instructor set Manger=NULL where Manger=@id
delete from Instructor
where Ins_id = @id
end
else
begin
select 'There is no Instructor with that ID'
end

----------------------------------------------
go
create or alter proc DeleteTopic @id int
as
if exists (select * from Topic where Topic_id = @id)
begin
delete from Topic
where Topic_id = @id
end
else
begin
select 'There is no Topic with that ID'
end

----------------------------------
go
create or alter proc DeleteChoice @id int
as
if exists(select * from Choices where choice_id = @id)
begin
delete from Choices
where choice_id = @id
end
else
begin
select 'There is no Choice with that ID'
end

------------------------------------------
go
create or alter proc DeleteStdCourse @id int
as
delete from Std_Crs
where crs_id = @id

-----------------------------------------


































           
			
			
   