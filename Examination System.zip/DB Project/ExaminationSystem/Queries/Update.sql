
--Department
 create or alter proc UpdateDepartmentName @id int,@Name varchar(10)

 as
  update Department set dept_name=@name where Dept_id=@id;

  go
 --Student
 create or alter proc UpdateStudentFname @id int,@Name varchar(10)
 as
  update Student set Fname=@name where [Std-id]=@id;
 go

  create or alter proc UpdateStudentLname @id int,@Name varchar(10)
 as
  update Student set Lname=@name where [Std-id]=@id;
 
 go
  create or alter proc UpdateStudentAddress @id int,@address varchar(10)
 as
  update Student set Address=@address where [Std-id]=@id;
 
  go
  create or alter proc UpdateStudentUsername @id int,@username varchar(10)
  as
  update Student set Username=@username where [Std-id]=@id;
  go
  

 --Instructor
 go
  create or alter proc UpdateInstructorUsername @id int,@username varchar(10)
 as
  update Instructor set Username=@username where Ins_id=@id;
 
 go
 
 create or alter proc UpdateInstructorSalary @id int,@sal varchar(10)
 as
  update Instructor set Salary=@sal where Ins_id=@id;
 go

 create or alter proc UpdateInstructorFname @id int,@fname varchar(10)
 as
  update Instructor set Fname=@fname where Ins_id=@id;
 go

  create or alter proc UpdateInstructorLname @id int,@lname varchar(10)
 as
  update Instructor set Lname=@lname where Ins_id=@id;
 go

  create or alter proc UpdateInstructorDept @id int,@dept_id varchar(10)
 as
  update Instructor set Dept_id=@dept_id where Ins_id=@id;
 go
  create or alter proc UpdateInstructorManager @id int,@manager varchar(10)
 as
  update Instructor set Dept_id=@manager where Ins_id=@id;
 go
 --Topic
  create or alter proc UpdateTopicName @topic_id int,@Topic_name varchar(10)
 as
  update Topic set Topic_Name=@Topic_name where Topic_id=@topic_id;
 go
 
  create or alter proc UpdateTopicForCourse @topic_id int,@Crs_id int
 as
  update Topic set Crs_id=@Crs_id where Topic_id=@topic_id;
 go
 --Exam
  create or alter proc UpdateExamDuration @id int, @duration time(7)
 as
  update Exam set Duration=@duration where Exam_id=@id;
 go
--Question
 create or alter proc UpdateQusetingAndType @id int, @qus varchar(max),@type varchar(50)
 as
  update Questions set Question=@qus where Ques_id=@id
  update Questions set Type=@type where Ques_id=@id
 go
 --Choice
 create or alter proc UpdateChoices @id int,@choice varchar(50)
 as

  update Choices set Choice=@choice where choice_id=@id

  go
  create or alter proc UpdateQuesOfChoice @id int,@choice_id int
 as
 update Choices set choice_id=@choice_id where Ques_id=@id
 go

--Course
   create or alter proc UpdateCourseName @id int,@name varchar(10)
 as
 update Courses set crs_Name=@name where crs_id=@id
 go

 --Ques-Answer
 create or alter proc UpdateQuesAnswer @id int,@Answer varchar(50)
 as
 update Ques_Answer set Answer=@Answer where Ques_id=@id
 go
--------------------------------------------------------------------------