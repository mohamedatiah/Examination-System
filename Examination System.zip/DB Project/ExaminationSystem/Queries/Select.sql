		GO
		create or  alter proc SelectCourses
		as
		begin
		select * from Courses
		end

		
		-------------------------------------------------------------------------------
		GO

		create or alter proc SelectDepartment
		as
		begin
		select * from Department
		end
		--------------------------------------------------------------------------------
		GO

		create or alter proc SelectExam
		as
		begin
	    select * from Exam
		end

		-------------------------------------------------------------------------------
		GO

		create or alter proc Select_Ins_Course
		as
		begin
		select * from Course_ins
		end 

		--------------------------------------------------------------------------------
		GO

		create or alter proc Select_Question
		as
		begin
		select * from Questions
		end
		----------------------------------------------------------------------------------
		GO

		create or alter proc Select_QuestionAnswer
		as
		begin
		select * from Ques_Answer
		end
		----------------------------------------------------------------------------------

		go
		create or alter proc GetAllStudents
		as
		select * from Student

		------------------------------------------
		go
		create or alter proc GetAllInstructors
		as
		select * from dbo.Instructor

		------------------------------------------
		go
		create or alter proc GetTopics
		as
		select * from dbo.Topic

		--------------------------------------------
		go
		create or alter proc GetChoice
		as
		select * from dbo.Choices

		-------------------------------------------
		go
		create or alter proc GetStdCourse
		as
		select * from dbo.Std_Crs

		-------------------------------------------
		go
		create or alter proc GetFinalDegree
		as
		select * from dbo.FinalDegree

		exec GetFinalDegree












